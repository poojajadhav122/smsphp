today we did in login and register form in form we given id and button also given type="button" and down give form "text msg" and we  doing jquery in footer and in js folder we create sms.js file and we given the register 


when we give type="submit" that give the op to the url on the link

when we give type="button" that time we give class for button that we call in the js form and also 