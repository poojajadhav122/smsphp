<?php
  require_once 'connection.php';
  //print_r($_POST);

  $id = $_POST['x'];
  //echo $id;
  //exit;
  $str = "select * from contacts where cgrid='$id'";
  //echo $str;
 // exit;

  $res = $conn->query($str) or die($conn->error);
  //print_r($res);
  //exit;

  if($res->num_rows > 0){
  	echo "<h4> Contacts</h4>";
  	echo "<ul>";
  	while($ans = $res->fetch_array(MYSQLI_ASSOC)){
  		print_r($ans);
  		echo "<hr/>";
  		$mob = $ans['cmobile'];
  		$email = $ans['cemail'];
  		echo "<li class='contact_details' for='$mob#$email'>";
  		echo $ans['cname'];
  		echo "</li>";
  	}
  echo "</ul>";	 
  }


 ?>