<?php
require_once 'connection.php';
print_r($_POST);

if(empty($_POST['libid']))
{
	echo "please select library";
}
elseif(empty($_POST['content']))
{
	echo "please enter message";
}
elseif(strlen($_POST['content']) <5 || strlen($POST['content']) >200){
	echo "message length is valid from 5 to 200";
}
else{
	$id = $_POST['libid'];
	$mes = $_POST['content'];
	$str = "insert into message (mcontent,mlibid) values('$mes','$id')";
	$res = $conn->query($str) or die($conn->error);
	if($res){
		echo "message added";
	}
}
?>