<?php 

 session_start();
 if(!isset($_SESSION['sms'])){ //if user login that time it sholud go to library page
  header("location:logout.php");// if user not login so it sholud go to logout page
 } 
  require_once 'header.php';
?>
      <div id="content-wrapper">
        <div class="container-fluid">
          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Message Page</a>
            </li>
            <li class="breadcrumb-item active">Overview</li>
          </ol>


          <div class="card card-register mx-auto mt-5">
        <div class="card-header">Add Message</div>
        <div class="card-body">
          <form id="message_form">
            
            <div class="form-group">
              <div class="form-label-group">
                <?php
                    $id = $_SESSION['uid'];
                    $str = "select libid,libname from library where libuid='$id'";
                    //echo $str;
                    $res = $conn->query($str) or die($conn->error);
                   // print_r($res); //to dispaly in message page so we have to do this query first to check all library list coming in the mssage from or not

                ?>
                <select class="form-control" name="libid">
                  <option value=""> Please Select Library</option>

                  <?php
                   if($res->num_rows > 0):

                     while($ans= $res->fetch_object()):
                      print_r($ans);
                  ?>
                  <option value="<?php echo $ans->libid;?>"><?php echo $ans->libname;?></option> <!-- here we give the print the id and name of the library -->
                  <?php
                     
                   endwhile;
                 endif;
                  ?>
                </select>

                
              </div>
            </div>

             <div class="form-group">
              <div class="form-label-group">
                <textarea class="form-control" name="content" placeholder="enter message"></textarea>
              </div>
            </div>

          
            <button class="btn btn-primary btn-block btn-message" type="button">Add</button>
          </form>
          <div class="text-center msg"> <!-- here write msg because we using js --> 
            
          </div>
        </div>
      </div>
        </div>
        <!-- /.container-fluid -->
      </div>
      <!-- /.content-wrapper -->
<?php  
  require_once 'footer.php';
?>
    