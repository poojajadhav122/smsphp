<?php  
  require_once 'header.php';
?>
      <div id="content-wrapper">
        <div class="container-fluid">
          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Overview</li>
          </ol>
          <h2>send sms</h2>
          <hr>
          <div class="container">
            <div class="row">
              <div class="col-md-4">
                <h4>Show library</h4>
                <?php
                $uid =$_SESSION['uid'];
                 $str = "select libid,libname from library where libuid='$uid'";
                    //echo $str;
                    $res = $conn->query($str) or die($conn->error);
                    //print_r($res);

                    if($res->num_rows > 0){
                      echo "<ul>";
                      while($ans = $res->fetch_array(MYSQLI_ASSOC)){
                        //print_r($ans);
                        //echo "<br/>";
                        $id=$ans['libid'];
                        echo"<li class='libdata' for='$id'>";
                        echo $ans['libname'];
                         echo "<li >";//here we taken class for click and for taken to get the id this is taken for to show messag at output by click the libray name
                       
                      }
                      echo "</ul>";
                    }
                ?>
                <div class="message_data"></div>
              </div>
              <div class="col-md-4">
                <form id="form_message">
                  <ul>
                    <li>name</li>
                    <li><input type="text" name="name_m" class="name_m"></li>
                    <li>mobile</li>
                    <li><input type="text" name="mobile_m" class="mobile_m"></li>
                    <li>email</li>
                    <li><input type="text" name="email_m" class="email_m"></li>
                    <li>message</li>
                    <li><input type="text" name="message_m" class="message_m"></li>
                    <li ><textarea type="text" name="message_m" class="message_m"></textarea></li>
                    <li><button type="button" class="send_message">send message</button></li>

                  </ul>
                  <div class="errMsg"></div>
                </form>
              </div>
              <div class="col-md-4">
                <h4>Show group</h4>
                <?php
                $uid =$_SESSION['uid'];// this id taking from the session
                 $str = "select grid,grname from usergroup where gruid='$uid'";
                    //echo $str;
                    $res = $conn->query($str) or die($conn->error);
                    //print_r($res);

                    if($res->num_rows > 0){
                      echo "<ul>";
                      while($ans = $res->fetch_array(MYSQLI_ASSOC)){
                        //print_r($ans);
                        //echo "<br/>";
                        $id=$ans['grid'];
                        echo "<li class='groupdata' for='$id'>";
                      
                        echo $ans['grname'];
                        echo "</li>";
                      }
                      echo "</ul>";
                    }
                ?>
                <div class="group_data"></div>

                
                      
              </div>
            </div>
          </div>
        </div>
        <!-- /.container-fluid -->
      </div>
      <!-- /.content-wrapper -->
<?php  
  require_once 'footer.php';
?>
    