<?php  
  require_once 'header.php';
?>
      <div id="content-wrapper">
        <div class="container-fluid">
          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Overview</li>
          </ol>
          <h2>send sms</h2>
          <hr>
          <div class="container">
            <div class="row">
              <div class="col-md-4">
                <h4>Show library</h4>
                <?php
                $uid =$_SESSION['uid'];
                 $str = "select libid,libname from library where libuid='$uid'";
                    //echo $str;
                    $res = $conn->query($str) or die($conn->error);
                    //print_r($res);

                    if($res->num_rows > 0){
                      echo "<ul>";
                      while($ans = $res->fetch_array(MYSQLI_ASSOC)){
                        //print_r($ans);
                        //echo "<br/>";
                        $id=$ans['libid'];
                        echo"<li class='libdata' for='$id'>";
                        echo $ans['libname'];
                         echo "<li >";//here we taken class for click and for taken to get the id this is taken for to show messag at output by click the libray name
                        echo $ans['libname'];
                        echo "</li>";
                      }
                      echo "</ul>";
                    }
                ?>
                <div class="message_data"></div>
              </div>
              <div class="col-md-4">
                test
              </div>
              <div class="col-md-4">
                <h4>Show group</h4>
                <?php
                $uid =$_SESSION['uid'];// this id taking from the session
                 $str = "select grid,grname from usergroup where gruid='$uid'";
                    //echo $str;
                    $res = $conn->query($str) or die($conn->error);
                    //print_r($res);

                    if($res->num_rows > 0){
                      echo "<ul>";
                      while($ans = $res->fetch_array(MYSQLI_ASSOC)){
                        //print_r($ans);
                        //echo "<br/>";
                        echo"<li>";
                        echo $ans['grname'];
                        echo "</li>";
                      }
                      echo "</ul>";
                    }
                ?>
              </div>
            </div>
          </div>
        </div>
        <!-- /.container-fluid -->
      </div>
      <!-- /.content-wrapper -->
<?php  
  require_once 'footer.php';
?>
    