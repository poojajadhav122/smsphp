<?php
require_once 'connection.php';
//print_r($_POST);

$id = $_POST['x'];
//echo $id;

$str = "select mid,mcontent from message where mlibid='$id'";
//echo $str;
$res = $conn->query($str) or die($conn->error);

if($res->num_rows >0){
	echo "<h4>Message </h4>";
	echo "<ul>";
	while($ans = $res->fetch_array(MYSQLI_ASSOC)){
		//print_r($ans);
		//echo "<hr />";
		echo "<li class='message_details'>";
		echo $ans['mcontent'];
		echo "</li>";
	}
	echo "</ul>";
}
?>