<?php
require_once 'connection.php';
//print_r($_POST);

$email = $_POST['email_m'];
$mob = $_POST['mobile_m'];
$name = $_POST['name_m'];
$mes =urlencode($_POST['message_m']);


/////email////////
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= 'From: <vishal@php-training>' . "\r\n";
$subject = "test for mail";
$res = mail($email,$subject,$mes,$headers);
var_dump($res);

/////email////////

///////sms//////
$str = "http://api.textlocal.in/send/?username=chaitralisanap@gmail.com&hash=08deb98bc3e198db7b99ce5b96b88f00c50f2ca143d43483d71fd2eea3e7950c&message=$mes&sender=TXTLCL&numbers=91$mob&test=0";
echo $str;
$res = file($str);
var_dump($res);
///////sms//////
?>