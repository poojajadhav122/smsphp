//alert("file load")
$(document).ready(function () {
	//alert("jquery upload")

	$(".btn-login").click(function(){
		//alert("button click test")
		var data = $("#login_form").serialize();
		console.log(data)
    $.post("login-action.php",data,function(response){
    	console.log(response)
    	$(".msg").html(response)
    })
	})

	$(".btn-register").click(function(){
		//alert("button click test")
		var data = $("#register_form").serialize();
		//console.log(data)
    $.post("register-action.php",data,function(response){
    	console.log(response)
    	$(".msg").html(response)
    })
	})
})