//alert("file load")
$(document).ready(function () {
	//alert("jquery upload")

	$(".btn-login").click(function(){
		//alert("button click test")
		var data = $("#login_form").serialize();
		console.log(data)
    $.post("login-action.php",data,function(response){
    	console.log(response)
    	if(response == "success"){ // this write after the login become suucess so we have to give redirect page
             window.location.href="index.php";
    	}
    	else{
    		$(".msg").html(response)

    	}
    	
    })
	})

	$(".btn-register").click(function(){
		//alert("button click test")
		var data = $("#register_form").serialize();
		//console.log(data)
    $.post("register-action.php",data,function(response){
    	console.log(response)
    	$(".msg").html(response)
    })
	})
})