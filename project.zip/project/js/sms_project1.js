//alert("file load")
$(document).ready(function () {
	//alert("jquery upload")

	
	$(".btn-library").click(function(){
		//alert("button click test")
		var data = $("#library_form").serialize();
		//console.log(data)
    $.post("library-action.php",data,function(response){
    	console.log(response)
    	$(".msg").html(response)
    })
	})

    $(".btn-group").click(function(){
        //alert("button click test")
        var data = $("#group_form").serialize();
        //console.log(data)
    $.post("group-action.php",data,function(response){
        console.log(response)
        $(".msg").html(response)
    })
    })

     $(".btn-message").click(function(){
        //alert("button click test")
        var data = $("#message_form").serialize();
        //console.log(data)
    $.post("message-action.php",data,function(response){
        console.log(response)
        $(".msg").html(response)
    })
    })

      $(".btn-contact").click(function(){
        //alert("button click test")
        var data = $("#contact_form").serialize();
        //console.log(data)
    $.post("contact-action.php",data,function(response){
        console.log(response)
        $(".msg").html(response)
    })
    })

      $(".libdata").click(function(){
        var rec = $(this).attr("for") // here we take one varibale becuae we have to single library and this attr(for) show the id in backside of the srver side show id
        alert(rec)
        $.post("get_message.php","x="+rec,function(response){ // "x=" in this we not useing serialize because we have to show single record so that why we using the x the we append becuse values come in the key way so we did append
            console.log(response)
            $(".message_data").html(response)
        })
      })
})