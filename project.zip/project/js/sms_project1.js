//alert("file load")
$(document).ready(function () {
	//alert("jquery upload")

	
	$(".btn-library").click(function(){
		//alert("button click test")
		var data = $("#library_form").serialize();
		//console.log(data)
    $.post("library-action.php",data,function(response){
    	console.log(response)
    	$(".msg").html(response)
    })
	})

    $(".btn-group").click(function(){
        //alert("button click test")
        var data = $("#group_form").serialize();
        //console.log(data)
    $.post("group-action.php",data,function(response){
        console.log(response)
        $(".msg").html(response)
    })
    })
})