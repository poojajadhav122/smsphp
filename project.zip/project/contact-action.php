<?php
require_once 'connection.php';
print_r($_POST);

if(empty($_POST['libid']))
{
	echo "please select group";
}
elseif(empty($_POST['cname']))
{
	echo "please enter name";
}
elseif(empty($_POST['cmobile']))
{
	echo "please enter mobile no";
}
elseif(empty($_POST['cemail']))
{
	echo "please enter email";
}
else{
  $id =$_POST['libid'];
  $cname =$_POST['cname'];
  $cmobile =$_POST['cmobile'];
  $cemail =$_POST['cemail'];

  $str = "insert into contacts (cname,cmobile,cemail,cgrid) values('$cname','$cmobile','$cemail','$id')";
	$res = $conn->query($str) or die($conn->error);
	if($res){
		echo "conatct added";
	}
}

?>