<?php 

 session_start();
 if(!isset($_SESSION['sms'])){ //if user login that time it sholud go to library page
  header("location:logout.php");// if user not login so it sholud go to logout page
 } 
  require_once 'header.php';
?>
      <div id="content-wrapper">
        <div class="container-fluid">
          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Message Page</a>
            </li>
            <li class="breadcrumb-item active">Overview</li>
          </ol>


          <div class="card card-register mx-auto mt-5">
        <div class="card-header">Add Contact</div>
        <div class="card-body">
          <form id="contact_form">
            
            <div class="form-group">
              <div class="form-label-group">
                <?php
                    $id = $_SESSION['uid'];
                    $str = "select grid,grname from usergroup where gruid='$id'";
                    //echo $str; //to dispaly in contact page so we have to do this query first to check all group list coming in the mssage from or not

                    $res = $conn->query($str) or die($conn->error);
                    //print_r($res);

                ?>
                <select class="form-control" name="libid">
                  <option value=""> Please Select Group</option>

                  <?php
                   if($res->num_rows > 0):
                     while($ans= $res->fetch_object()):
                  ?>
                  <option value="<?php echo $ans->grid;?>"><?php echo $ans->grname;?></option><!-- here we give the print the id and name of the library -->
                  <?php
                     
                   endwhile;
                 endif;
                  ?>
                </select>

                
              </div>
            </div>

             <div class="form-group">
              <div class="form-label-group">
                <input type="text" name="cname" id="inputEmail" class="form-control" placeholder="Enter name" >
                <label for="inputName">Name</label>
              </div>
            </div>

            
            <div class="form-group">
              <div class="form-label-group">
                <input type="text" name="cmobile" id="inputEmail" class="form-control" placeholder="Enter name" >
                <label for="inputName"> Mobile</label>
              </div>
            </div>
            <div class="form-group">
              <div class="form-label-group">
                <input type="text" name="cemail" id="inputEmail" class="form-control" placeholder="Enter name" >
                <label for="inputName"> Email</label>
              </div>
            </div>

          
            <button class="btn btn-primary btn-block btn-contact" type="button">Add</button>
          </form>
          <div class="text-center msg"> <!-- here write msg because we using js --> 
            
          </div>
        </div>
      </div>
        </div>
        <!-- /.container-fluid -->
      </div>
      <!-- /.content-wrapper -->
<?php  
  require_once 'footer.php';
?>
    